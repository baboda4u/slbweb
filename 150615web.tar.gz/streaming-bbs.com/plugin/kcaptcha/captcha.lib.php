<?php
require(dirname(__FILE__).'/kcaptcha.lib.php');
?>