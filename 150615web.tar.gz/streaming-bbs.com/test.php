<html>
<head>
<script src="http://jwpsrv.com/library/wUK+wACLEeWPQRJtO5t17w.js"></script>
</head>
<body>
<div id='playerpyDxbiNEOMGJ'></div>
<script type='text/javascript'>
    jwplayer('playerpyDxbiNEOMGJ').setup({
        file: 'rtmp://128.199.248.227/flvplayback/livestream',
        image: 'http://hanmonet.com/img/logo.jpg',
        title: 'hanmonet',
        width: '100%',
        aspectratio: '16:9',
        autostart: 'true'
    });
</script>
</body>

</html>