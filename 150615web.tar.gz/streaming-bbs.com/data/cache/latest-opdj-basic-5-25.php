<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='충청O.P';
$list=array (
)?>