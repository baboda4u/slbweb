<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='지역모임방';
$list=array (
)?>