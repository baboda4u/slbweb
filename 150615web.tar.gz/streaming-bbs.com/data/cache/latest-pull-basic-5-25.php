<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='주점(풀.룸)';
$list=array (
)?>