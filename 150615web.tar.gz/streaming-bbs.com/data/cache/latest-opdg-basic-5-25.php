<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='경상O.P';
$list=array (
)?>