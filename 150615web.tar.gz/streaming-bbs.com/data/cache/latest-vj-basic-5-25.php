<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='VJ 응원란';
$list=array (
  0 => 
  array (
    'wr_id' => '2',
    'wr_num' => '-1',
    'wr_reply' => '',
    'wr_parent' => '2',
    'wr_is_comment' => '0',
    'wr_comment' => '0',
    'wr_comment_reply' => '',
    'ca_name' => '',
    'wr_option' => '',
    'wr_subject' => 'VJ응원란',
    'wr_content' => '​이 게시판은 VJ들이 라이브 방송을 할때 
VJ에게 바라는 점이나 어떤테마의 방송을 해줬으면 하는지 
회원님들의 의견을 최대한 반영하도록 하겠습니다 
또한 라이브 방송때 어떤 물품이 경매로 나오면 좋을지 
예를들면 속옷 색상 디자인 경매 낙찰시 착용실사 자세등등... 
VJ경매를 통한 수익은 100% VJ에게 지급이 됩니다',
    'wr_link1' => '',
    'wr_link2' => '',
    'wr_link1_hit' => '0',
    'wr_link2_hit' => '0',
    'wr_hit' => '1',
    'wr_good' => '0',
    'wr_nogood' => '0',
    'mb_id' => 'slbadmin',
    'wr_password' => '*DD988866FB2A84A0FCDDBB57CACA14D64AA4A815',
    'wr_name' => '최고관리자',
    'wr_email' => 'ybbs001@gmail.com',
    'wr_homepage' => '',
    'wr_datetime' => '2015-06-04 04:39:24',
    'wr_file' => '0',
    'wr_last' => '2015-06-04 04:39:24',
    'wr_ip' => '58.237.81.88',
    'wr_facebook_user' => '',
    'wr_twitter_user' => '',
    'wr_1' => '',
    'wr_2' => '',
    'wr_3' => '',
    'wr_4' => '',
    'wr_5' => '',
    'wr_6' => '',
    'wr_7' => '',
    'wr_8' => '',
    'wr_9' => '',
    'wr_10' => '',
    'is_notice' => true,
    'subject' => 'VJ응원란',
    'comment_cnt' => '',
    'datetime' => '2015-06-04',
    'datetime2' => '06-04',
    'last' => '2015-06-04',
    'last2' => '06-04',
    'name' => '<span class="sv_member">최고관리자</span>',
    'reply' => 0,
    'icon_reply' => '',
    'icon_link' => '',
    'ca_name_href' => 'http://koreaslb.com/bbs/board.php?bo_table=vj&amp;sca=',
    'href' => 'http://koreaslb.com/bbs/board.php?bo_table=vj&amp;wr_id=2',
    'comment_href' => 'http://koreaslb.com/bbs/board.php?bo_table=vj&amp;wr_id=2',
    'icon_new' => '',
    'icon_hot' => '',
    'icon_secret' => '',
    'link' => 
    array (
      1 => NULL,
      2 => NULL,
    ),
    'link_href' => 
    array (
      1 => 'http://koreaslb.com/bbs/link.php?bo_table=vj&amp;wr_id=2&amp;no=1',
      2 => 'http://koreaslb.com/bbs/link.php?bo_table=vj&amp;wr_id=2&amp;no=2',
    ),
    'link_hit' => 
    array (
      1 => 0,
      2 => 0,
    ),
    'file' => 
    array (
      'count' => '0',
    ),
  ),
)?>