<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='일반갤러리';
$list=array (
)?>