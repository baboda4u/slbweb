<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='O.P후기';
$list=array (
)?>