<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='서양관';
$list=array (
  0 => 
  array (
    'wr_id' => '5',
    'wr_num' => '-3',
    'wr_reply' => '',
    'wr_parent' => '5',
    'wr_is_comment' => '0',
    'wr_comment' => '0',
    'wr_comment_reply' => '',
    'ca_name' => '',
    'wr_option' => 'html2',
    'wr_subject' => '서양',
    'wr_content' => '<table border="1" width="526" height="463" bgcolor="black" align="center" cellspacing="0" bordercolordark="white" bordercolorlight="black">
<tr><td width="520" align="center" valign="middle" height="404">
<!-- 동영상주소--><embed src="http://video.fc2.com/flv2.swf?i=20150527NWEXs0d0" quality="high" bgcolor="#ffffff" wmode="transparent" width="500" height="400" name="flv2" align="middle" allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" allowfullscreen="true"></embed>
</td></tr><tr><td width="520" height="54" align="center" valign="middle">
<table width="520" height="50" align="center" cellpadding="0" cellspacing="0"><tr>
<td width="262" align="center" valign="middle"><b><span style="font-size:10pt;" color="white">
<marquee scrollamount=1 onmouseover=this.stop() onmouseout=this.start()>


<a target="_blank" href="http://pan.baidu.com/s/1sj7dEVF" target="_blank" style="text-decoration:none"> <!-- 다운로드링크주소-->
<font color="white">[다운로드 링크]</font></a>                   <!-- 링크제목-->


<font color="white">  &nbsp; 
    
   암호：mj58    <!-- 다운로드링크암호-->
 


</font></span></p></td></tr></table></td></tr></table>',
    'wr_link1' => '',
    'wr_link2' => '',
    'wr_link1_hit' => '0',
    'wr_link2_hit' => '0',
    'wr_hit' => '10',
    'wr_good' => '0',
    'wr_nogood' => '0',
    'mb_id' => 'ybbsadmin',
    'wr_password' => '*B891F123DEFE9321113ADE2F90227E67D29B09F7',
    'wr_name' => '최고관리자',
    'wr_email' => 'ybbs001@gmail.com',
    'wr_homepage' => '',
    'wr_datetime' => '2015-05-28 16:42:28',
    'wr_file' => '0',
    'wr_last' => '2015-05-28 16:42:28',
    'wr_ip' => '106.242.202.187',
    'wr_facebook_user' => '',
    'wr_twitter_user' => '',
    'wr_1' => '',
    'wr_2' => '',
    'wr_3' => '',
    'wr_4' => '',
    'wr_5' => '',
    'wr_6' => '',
    'wr_7' => '',
    'wr_8' => '',
    'wr_9' => '',
    'wr_10' => '',
    'is_notice' => false,
    'subject' => '서양',
    'comment_cnt' => '',
    'datetime' => '2015-05-28',
    'datetime2' => '05-28',
    'last' => '2015-05-28',
    'last2' => '05-28',
    'name' => '<span class="sv_member">최고관리자</span>',
    'reply' => 0,
    'icon_reply' => '',
    'icon_link' => '',
    'ca_name_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;sca=',
    'href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=5',
    'comment_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=5',
    'icon_new' => '',
    'icon_hot' => '',
    'icon_secret' => '',
    'link' => 
    array (
      1 => NULL,
      2 => NULL,
    ),
    'link_href' => 
    array (
      1 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=5&amp;no=1',
      2 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=5&amp;no=2',
    ),
    'link_hit' => 
    array (
      1 => 0,
      2 => 0,
    ),
    'file' => 
    array (
      'count' => '0',
    ),
  ),
  1 => 
  array (
    'wr_id' => '2',
    'wr_num' => '-2',
    'wr_reply' => '',
    'wr_parent' => '2',
    'wr_is_comment' => '0',
    'wr_comment' => '0',
    'wr_comment_reply' => '',
    'ca_name' => '',
    'wr_option' => 'html2',
    'wr_subject' => '음악2',
    'wr_content' => '<iframe title=\'BoA Kiss My Lips M/V\' width=\'640px\' height=\'360px\' src=\'http://videofarm.daum.net/controller/video/viewer/Video.html?vid=vd8c4DIexIre4AcDSrcZP88&play_loc=undefined\' frameborder=\'0\' scrolling=\'no\' ></iframe>',
    'wr_link1' => '',
    'wr_link2' => '',
    'wr_link1_hit' => '0',
    'wr_link2_hit' => '0',
    'wr_hit' => '9',
    'wr_good' => '0',
    'wr_nogood' => '0',
    'mb_id' => 'ybbsadmin',
    'wr_password' => '*B891F123DEFE9321113ADE2F90227E67D29B09F7',
    'wr_name' => '최고관리자',
    'wr_email' => 'ybbs001@gmail.com',
    'wr_homepage' => '',
    'wr_datetime' => '2015-05-27 13:56:00',
    'wr_file' => '0',
    'wr_last' => '2015-05-27 13:56:00',
    'wr_ip' => '106.242.202.187',
    'wr_facebook_user' => '',
    'wr_twitter_user' => '',
    'wr_1' => '',
    'wr_2' => '',
    'wr_3' => '',
    'wr_4' => '',
    'wr_5' => '',
    'wr_6' => '',
    'wr_7' => '',
    'wr_8' => '',
    'wr_9' => '',
    'wr_10' => '',
    'is_notice' => false,
    'subject' => '음악2',
    'comment_cnt' => '',
    'datetime' => '2015-05-27',
    'datetime2' => '05-27',
    'last' => '2015-05-27',
    'last2' => '05-27',
    'name' => '<span class="sv_member">최고관리자</span>',
    'reply' => 0,
    'icon_reply' => '',
    'icon_link' => '',
    'ca_name_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;sca=',
    'href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=2',
    'comment_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=2',
    'icon_new' => '',
    'icon_hot' => '',
    'icon_secret' => '',
    'link' => 
    array (
      1 => NULL,
      2 => NULL,
    ),
    'link_href' => 
    array (
      1 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=2&amp;no=1',
      2 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=2&amp;no=2',
    ),
    'link_hit' => 
    array (
      1 => 0,
      2 => 0,
    ),
    'file' => 
    array (
      'count' => '0',
    ),
  ),
  2 => 
  array (
    'wr_id' => '1',
    'wr_num' => '-1',
    'wr_reply' => '',
    'wr_parent' => '1',
    'wr_is_comment' => '0',
    'wr_comment' => '0',
    'wr_comment_reply' => '',
    'ca_name' => '',
    'wr_option' => 'html2',
    'wr_subject' => '음악',
    'wr_content' => '<iframe width="560" height="315" src="https://www.youtube.com/embed/For5ZEOdNWU" frameborder="0" allowfullscreen></iframe>',
    'wr_link1' => '',
    'wr_link2' => '',
    'wr_link1_hit' => '0',
    'wr_link2_hit' => '0',
    'wr_hit' => '5',
    'wr_good' => '0',
    'wr_nogood' => '0',
    'mb_id' => 'ybbsadmin',
    'wr_password' => '*B891F123DEFE9321113ADE2F90227E67D29B09F7',
    'wr_name' => '최고관리자',
    'wr_email' => 'ybbs001@gmail.com',
    'wr_homepage' => '',
    'wr_datetime' => '2015-05-27 13:50:23',
    'wr_file' => '0',
    'wr_last' => '2015-05-27 13:50:23',
    'wr_ip' => '106.242.202.187',
    'wr_facebook_user' => '',
    'wr_twitter_user' => '',
    'wr_1' => '',
    'wr_2' => '',
    'wr_3' => '',
    'wr_4' => '',
    'wr_5' => '',
    'wr_6' => '',
    'wr_7' => '',
    'wr_8' => '',
    'wr_9' => '',
    'wr_10' => '',
    'is_notice' => false,
    'subject' => '음악',
    'comment_cnt' => '',
    'datetime' => '2015-05-27',
    'datetime2' => '05-27',
    'last' => '2015-05-27',
    'last2' => '05-27',
    'name' => '<span class="sv_member">최고관리자</span>',
    'reply' => 0,
    'icon_reply' => '',
    'icon_link' => '',
    'ca_name_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;sca=',
    'href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=1',
    'comment_href' => 'http://koreaslb.com/bbs/board.php?bo_table=west&amp;wr_id=1',
    'icon_new' => '',
    'icon_hot' => '',
    'icon_secret' => '',
    'link' => 
    array (
      1 => NULL,
      2 => NULL,
    ),
    'link_href' => 
    array (
      1 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=1&amp;no=1',
      2 => 'http://koreaslb.com/bbs/link.php?bo_table=west&amp;wr_id=1&amp;no=2',
    ),
    'link_hit' => 
    array (
      1 => 0,
      2 => 0,
    ),
    'file' => 
    array (
      'count' => '0',
    ),
  ),
)?>