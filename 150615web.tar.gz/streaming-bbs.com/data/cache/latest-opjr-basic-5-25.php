<?php
if (!defined('_GNUBOARD_')) exit;
$bo_subject='전라O.P';
$list=array (
)?>