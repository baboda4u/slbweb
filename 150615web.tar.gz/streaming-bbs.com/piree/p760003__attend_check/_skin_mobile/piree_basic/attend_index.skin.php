<?php

/*
===========================================================

	프로젝트 이름 : Piree Web Program

	만든사람 : 피리 PIREE

	홈페이지 : http://www.piree.co.kr

	작성날짜 : 2014년 01월 23일 목요일 오전 10시 38분, 날씨 추워~ B급으로 추워~

	저 작 권 : Copyright ⓒ 2014-2015 투스포츠 (원병철) All right reserved
							그누보드 외에 추가된 소스는~
							만든사람의 허락없이 무단으로 사용할수 없습니다.
							사용하고자 할 경우 만든사람의 허락을 받아야 합니다.
							http://www.piree.co.kr 에 문의해 주세요.

===========================================================
 피리 > 피리 출석체크 PLUS G5 > 스킨
===========================================================


*/


	#########################################################
	# 시작 => 선처리
	#########################################################

	//=======================================================
	// 개별_페이지__접근_불가
	IF (!defined("_GNUBOARD_"))										EXIT;

	#########################################################
	# 끝 => 선처리
	#########################################################



	#########################################################
	# 시작 => 보여주기
	#########################################################

	//=======================================================
	// 게시글에_투표__등록__스타일
	add_stylesheet('<link rel="stylesheet" href="'.$attend_config['skin_mobile_u'].'/style.css">', 75);

	#########################################################
	# 끝 => 보여주기
	#########################################################


?>

<!-- 시작 => 내가__몸통이다 -->

<section>


		<nav class="mobile_hor__list">
			<ul>

				<li>
					<div class="cont_padd_8">
						<strong><?php echo $cal_date_Y ?></strong>년
						<strong><?php echo $cal_date_m ?></strong>월
						<strong><?php echo $cal_date_d ?></strong>일 &nbsp;
						<strong><?php echo $cal_yoil_s ?></strong>
					</div>
				</li>

				<li>
					<div class="cont_padd_8">
						<span class="font_999">출석시간</span>
						<strong><?php echo $attend_start_time ?></strong> <span class="font_999">부터</span>
						<strong><?php echo $attend_close_time ?></strong> <span class="font_999">까지</span>
					</div>
				</li>

				<li>
					<div class="cont_padd_8">
						<span class="font_999">출석 포인트</span>
						<strong><?php echo $attend_config["attend_point"] ?></strong> <span class="font_999">점</span>
					</div>
				</li>

				<li>
					<div class="cont_padd_8">
						<span class="font_999">개근 포인트</span>
						<strong><?php echo $attend_config["regular_day_n"] ?></strong> <span class="font_999">일 연속 출석체크시</span>
						<strong><?php echo $attend_config["regular_point"] ?></strong> <span class="font_999">점</span>
					</div>
				</li>

				<li>
					<div class="cont_padd_8">
						<span class="font_999">출석체크</span>
						<strong><?php echo $cal_attend_t ?></strong> <span class="font_999">명 하였습니다.</span>
					</div>
				</li>

				<li>
					<div class="cont_padd_8">
						<span class="font_999">1등 포인트</span> <strong><?php echo $attend_config["rank_1_point"] ?></strong><span class="font_999">점</span>
					</div>
				</li>

			</ul>
		</nav>


		<div class="cl_bo space_10px"></div>


		<div style="height:5px; border-bottom:1px solid #efefef;"></div>

		<nav id="article_news">
		<h2>출석체크 하기</h2>
		<ul>
<?php

	//=======================================================
	// 시작 => 출석체크_목록__유무
	IF ($attend_view_n > 0)
	{

		#######################################################
		# 시작 => 출석체크_목록__있으면
		#######################################################

		//=====================================================
		// 시작 => 돌려라__반복문
		FOR ($i=0; $i<count($attend_list_arr); $i++)
		{

			//===================================================
			// 배열_변수
			$attend_lists = $attend_list_arr[$i];


			//===================================================
			// 시작 => 출석체크_순서__있으면
			IF ($attend_lists["seq_n"] > 0)
			{

				###################################################
				# 시작 => 출석체크_순서__있으면
				###################################################

				//=================================================
				// 출석_시간__오전_오후
				$attend_time_s = date("A", $attend_lists["regi_time_n"]) == "AM" ? "오전 " : "오후 ";


				//=================================================
				// 출석_시간__문자열
				$attend_time_s .= date("H:i", $attend_lists["regi_time_n"]);

?>
				<li>
					<div class="div_left_50"><?php echo $attend_lists["seq_n"] ?>등</div>
					<div class="div_left_cont"><strong><?php echo $attend_lists["mb_nick"] ?></strong></div>
					<br />
					<div class="div_left_50">&nbsp;</div>
					<div class="div_left_110"><?php echo $attend_time_s ?></div>
					<div class="div_left_110">연속 <?php echo $attend_lists["conti_n"] ?> 일</div>
					<br />
					<div class="div_left_50">&nbsp;</div>
					<div><?php echo $attend_lists["cont_s"] ?></div>
				</li>

<?php

			}
			// 끝 => 출석체크_순서__있으면
			//===================================================

		}
		// 끝 => 돌려라__반복문
		//=====================================================

		#######################################################
		# 끝 => 출석체크_목록__있으면
		#######################################################

	}
	ELSE
	{

		#######################################################
		# 시작 => 출석체크_목록__없으면
		#######################################################

?>
				<li>
					<p style="text-align:center"><strong>아직 출석체크하신 분이 없습니다.</strong></p>
				</li>

<?php

		#######################################################
		# 끝 => 출석체크_목록__없으면
		#######################################################

	}
	// 끝 => 출석체크_목록__유무
	//=======================================================

?>
		</nav>


		<div class="cl_bo space_10px"></div>

		<div class="cl_bo space_10px"></div>


<?php

	//=======================================================
	// 시작 => 출석_가능__여부
	IF ($is_use__attend == 1)
	{

		#######################################################
		# 시작 => 출석__가능_하면

?>
		<form name="attend_check_form" id="attend_check_form" action="<?php echo $attend_config['prog_u']; ?>attend.regist.php" method="post" onsubmit="return input__attend_check(this);">

		<div class="attend_check_do_out">

			<div class="attend_check_do_hr"></div>

			<div class="attend_check_do_body">
				한마디
				<input type="text" name="cont_s" id="cont_s" value="" class="frm_input required" size="42">
				<input type="submit" class="btn_submit" value=" 출석하기 ">
			</div>

			<div class="attend_check_do_hr"></div>

			<div class="attend_check_do_body">
				⊙ 한마디 남기시고 "출석하기" 버튼을 눌러 주세요!!
			</div>

		</div>

		</form>


	<script>
	function input__attend_check(gform)
	{

		//=====================================================
		// 시작 => 한마디_입력__안되었으면
		if (!document.getElementById("cont_s").value || document.getElementById("cont_s").value == "")
		{

			// 에러
			alert ("한마디 입력해 주세요.");
			document.getElementById("cont_s").focus();
			return false;

		}
		// 시작 => 한마디_입력__안되었으면
		//=====================================================


		//=====================================================
		// 통과~
		return true;

	}
	</script>
<?php

	}
	ELSE
	{

		#######################################################
		# 시작 => 출석__불가_하면

?>
		<div style="width:auto; padding:16px 0 16px 20px; background:#ecf5e5;">

			<div>
				<strong>지금은 출석 시간이 아닙니다.</strong>
			</div>

		</div>

<?php

	}
	// 끝 => 출석_가능__여부
	//=======================================================


	//=======================================================
	// 시작 => 전체_페이지__있으면
	IF ($total_page > 1)
	{
?>
		<div class="attend_check_do_out">

			<div class="attend_check_do_hr"></div>

			<div class="attend_check_do_body">
						<p style="text-align:center"><?php echo get_paging($config['cf_mobile_pages'], $page, $total_page, "?page="); ?></p>
			</div>

			<div class="attend_check_do_hr"></div>

		</div>

<?php
	}
	// 끝 => 전체_페이지__있으면
	//=======================================================

?>


</section>
<!-- 끝 => 내가__몸통이다 -->