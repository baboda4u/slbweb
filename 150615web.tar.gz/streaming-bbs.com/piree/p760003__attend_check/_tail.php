<?php
IF (!defined('_GNUBOARD_')) EXIT; // 개별_페이지__접근_불가

include_once (G5_PATH.'/tail.php');
?>