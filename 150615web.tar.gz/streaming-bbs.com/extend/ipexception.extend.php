<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$g5['ip_exception_table'] = G5_TABLE_PREFIX . 'ip_exception';



?>